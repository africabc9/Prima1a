# E2‑Z: Certification & Next Steps

*Content TBD*