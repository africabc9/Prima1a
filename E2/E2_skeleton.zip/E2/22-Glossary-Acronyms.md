# E2‑V: Glossary & Acronyms

*Content TBD*